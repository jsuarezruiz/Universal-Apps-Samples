﻿namespace Ejemplo_NavegacionMVVM.Services.Navigation
{
    /// <summary>
    /// Navigation service contract implementation
    /// </summary>
    public class NavigationService : INavigationService
    {
        /// <summary>
        /// This method performs a navigate back to the last page in the navigation stack.
        /// </summary>
        public void NavigateBack()
        {
            App.Frame.GoBack();
        }

        /// <summary>
        /// This method navigates to the specified Page
        /// </summary>
        /// <typeparam name="T">Page type</typeparam>
        /// <param name="parameter">optional, a parameter can be send with the navigation</param>
        public void NavigateTo<T>(object parameter = null)
        {
            if (parameter != null)
                App.Frame.Navigate(typeof(T), parameter);
            else
                App.Frame.Navigate(typeof(T));
        }

        /// <summary>
        /// This method clears the navigation backstack.
        /// </summary>
        public void ClearNavigationHistory()
        {
            App.Frame.BackStack.Clear();
        }
    }
}
