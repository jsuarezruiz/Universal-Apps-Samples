﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Ejemplo_NavegacionMVVM.ViewModels.Base
{
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        private bool _isBusy;

        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// This method allows Page and ViewModel to communicate navigation states
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnNavigatedTo(NavigationEventArgs e) { }

        /// <summary>
        /// This method allows Page and ViewModel to communicate navigation states
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnNavigatedFrom(NavigationEventArgs e) { }


        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChanged([CallerMemberName]string propertyName = "")
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
