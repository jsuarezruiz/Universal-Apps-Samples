﻿using Ejemplo_NavegacionMVVM.Services.Navigation;
using Ejemplo_NavegacionMVVM.ViewModels.Base;
using Ejemplo_NavegacionMVVM.Views;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Ejemplo_NavegacionMVVM.ViewModels
{
    public class Pagina1ViewModel : ViewModelBase
    {
        //Services
        private readonly INavigationService _navigationService;

        //Commands
        private ICommand _navigateCommand;

        public Pagina1ViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;
        }

        public ICommand NavigateCommand
        {
            get { return _navigateCommand = _navigateCommand ?? new DelegateCommand(NavigateCommandDelegate); }
        }

        public void NavigateCommandDelegate()
        {
            _navigationService.NavigateTo<Pagina2>("Esto es un parámetro!");
        }
    }
}
