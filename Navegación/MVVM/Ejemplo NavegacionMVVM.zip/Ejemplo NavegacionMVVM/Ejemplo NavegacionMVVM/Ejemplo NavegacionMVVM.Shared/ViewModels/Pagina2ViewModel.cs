﻿using Ejemplo_NavegacionMVVM.Services.Navigation;
using Ejemplo_NavegacionMVVM.ViewModels.Base;
using System.Diagnostics;
using System.Windows.Input;

namespace Ejemplo_NavegacionMVVM.ViewModels
{
    public class Pagina2ViewModel : ViewModelBase
    {
        //Services
        private readonly INavigationService _navigationService;

        //Commands
        private ICommand _navigateBackCommand;

        public Pagina2ViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;
        }

        public override void OnNavigatedTo(Windows.UI.Xaml.Navigation.NavigationEventArgs args)
        {
            if (args.Parameter != null)
                Debug.WriteLine(args.Parameter);
        }

        public ICommand NavigateBackCommand
        {
            get { return _navigateBackCommand = _navigateBackCommand ?? new DelegateCommand(NavigateBackCommandDelegate); }
        }

        public void NavigateBackCommandDelegate()
        {
            _navigationService.NavigateBack();
        }
    }
}
