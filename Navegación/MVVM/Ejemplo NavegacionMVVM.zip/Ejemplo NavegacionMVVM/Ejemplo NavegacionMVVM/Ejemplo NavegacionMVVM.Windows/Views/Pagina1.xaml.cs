﻿using Ejemplo_NavegacionMVVM.Views.Base;

namespace Ejemplo_NavegacionMVVM.Views
{
    /// <summary>
    /// Pagina1.
    /// </summary>
    public sealed partial class Pagina1 : PageBase
    {
        public Pagina1()
        {
            this.InitializeComponent();
        }
    }
}
