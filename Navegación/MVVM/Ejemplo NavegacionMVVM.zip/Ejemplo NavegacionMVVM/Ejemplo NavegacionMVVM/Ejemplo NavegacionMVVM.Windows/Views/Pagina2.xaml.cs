﻿using Ejemplo_NavegacionMVVM.Views.Base;

namespace Ejemplo_NavegacionMVVM.Views
{
    /// <summary>
    /// Pagina2.
    /// </summary>
    public sealed partial class Pagina2 : PageBase
    {
        public Pagina2()
        {
            this.InitializeComponent();
        }
    }
}
