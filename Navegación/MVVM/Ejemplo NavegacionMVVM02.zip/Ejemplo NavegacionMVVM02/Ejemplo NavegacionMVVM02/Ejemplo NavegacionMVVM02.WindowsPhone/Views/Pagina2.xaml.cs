﻿namespace Ejemplo_NavegacionMVVM02.Views
{
    /// <summary>
    /// Pagina2.
    /// </summary>
    public sealed partial class Pagina2
    {
        public Pagina2()
        {
            InitializeComponent();
        }
    }
}
