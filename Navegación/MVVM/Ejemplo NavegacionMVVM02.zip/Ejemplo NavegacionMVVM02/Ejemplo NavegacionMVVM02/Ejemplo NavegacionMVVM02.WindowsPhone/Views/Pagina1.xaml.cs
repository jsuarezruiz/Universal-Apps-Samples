﻿namespace Ejemplo_NavegacionMVVM02.Views
{
    /// <summary>
    /// Pagina1.
    /// </summary>
    public sealed partial class Pagina1
    {
        public Pagina1()
        {
            InitializeComponent();
        }
    }
}
