﻿using Microsoft.Practices.Unity;

namespace Ejemplo_NavegacionMVVM02.ViewModels.Base
{
    public class ViewModelLocator
    {
        readonly IUnityContainer _container;

        public ViewModelLocator()
        {
            _container = new UnityContainer();

            _container.RegisterType<Pagina1ViewModel>();
            _container.RegisterType<Pagina2ViewModel>();
        }

        public Pagina1ViewModel Pagina1ViewModel
        {
            get { return _container.Resolve<Pagina1ViewModel>(); }
        }

        public Pagina2ViewModel Pagina2ViewModel
        {
            get { return _container.Resolve<Pagina2ViewModel>(); }
        }
    }
}
