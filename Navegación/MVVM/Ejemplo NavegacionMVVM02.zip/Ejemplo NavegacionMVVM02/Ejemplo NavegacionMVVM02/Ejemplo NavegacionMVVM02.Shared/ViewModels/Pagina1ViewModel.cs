﻿using Ejemplo_NavegacionMVVM02.ViewModels.Base;
using Ejemplo_NavegacionMVVM02.Views;
using System.Windows.Input;

namespace Ejemplo_NavegacionMVVM02.ViewModels
{
    public class Pagina1ViewModel : ViewModelBase
    {
        //Commands
        private ICommand _navigateCommand;

        public override System.Threading.Tasks.Task OnNavigatedFrom(Windows.UI.Xaml.Navigation.NavigationEventArgs args)
        {
            return null;
        }

        public override System.Threading.Tasks.Task OnNavigatingFrom(Windows.UI.Xaml.Navigation.NavigatingCancelEventArgs args)
        {
            return null;
        }

        public override System.Threading.Tasks.Task OnNavigatedTo(Windows.UI.Xaml.Navigation.NavigationEventArgs args)
        {
            return null;
        }

        public ICommand NavigateCommand
        {
            get { return _navigateCommand = _navigateCommand ?? new DelegateCommand(NavigateCommandDelegate); }
        }

        public void NavigateCommandDelegate()
        {
            this.AppFrame.Navigate(typeof(Pagina2), "Esto es un parámetro");
        }
    }
}
