﻿using Ejemplo_NavegacionMVVM02.Views.Base;

namespace Ejemplo_NavegacionMVVM02.Views
{
    /// <summary>
    /// Pagina2.
    /// </summary>
    public sealed partial class Pagina2 : PageBase
    {
        public Pagina2()
        {
            this.InitializeComponent();
        }
    }
}
