﻿using ScreenRecorder.Views.Base;

namespace ScreenRecorder.Views
{
    /// <summary>
    ///     ResultView
    /// </summary>
    public sealed partial class ResultView : PageBase
    {
        public ResultView()
        {
            InitializeComponent();
        }
    }
}