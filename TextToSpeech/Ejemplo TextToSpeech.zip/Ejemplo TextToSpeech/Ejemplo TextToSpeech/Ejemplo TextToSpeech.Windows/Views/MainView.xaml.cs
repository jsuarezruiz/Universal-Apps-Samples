﻿using Windows.UI.Xaml.Controls;

namespace Ejemplo_TextToSpeech.Views
{
    /// <summary>
    /// MainView.
    /// </summary>
    public sealed partial class MainView : Page
    {
        public MainView()
        {
            this.InitializeComponent();
        }
    }
}
