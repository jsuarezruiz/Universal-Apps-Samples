﻿namespace Ejemplo_Sensor_Luz.Views
{
    using Base;

    /// <summary>
    /// MainView
    /// </summary>
    public sealed partial class MainView : PageBase
    {
        public MainView()
        {
            this.InitializeComponent();
        }
    }
}
