﻿namespace Ejemplo_Roaming_Settings.Views
{
    using Base;

    /// <summary>
    /// SettingsView
    /// </summary>
    public sealed partial class SettingsView : PageBase
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
}