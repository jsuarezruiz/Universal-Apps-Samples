﻿namespace Ejemplo_Roaming_Settings.Models
{
    public class Accent
    {
        public string Name { get; set; }

        public string Hex { get; set; }
    }
}
