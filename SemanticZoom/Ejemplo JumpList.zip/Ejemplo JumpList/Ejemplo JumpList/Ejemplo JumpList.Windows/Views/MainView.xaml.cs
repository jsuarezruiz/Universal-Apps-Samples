﻿using Windows.UI.Xaml.Controls;

namespace Ejemplo_JumpList.Views
{
    /// <summary>
    /// MainView
    /// </summary>
    public sealed partial class MainView : Page
    {
        public MainView()
        {
            this.InitializeComponent();
        }
    }
}
