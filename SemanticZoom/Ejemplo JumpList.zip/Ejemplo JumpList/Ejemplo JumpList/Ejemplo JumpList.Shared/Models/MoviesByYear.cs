﻿using System.Collections.Generic;

namespace Ejemplo_JumpList.Models
{
    public class MoviesByYear
    {
        public int Year { get; set; }
        public List<Movie> Movies { get; set; }
    }
}
